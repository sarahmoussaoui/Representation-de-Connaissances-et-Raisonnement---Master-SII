package be.fnord.util.logic;

import java.io.Serializable;

import orbital.moon.logic.ClassicalLogic;

public class ClassicalLogicS extends ClassicalLogic implements Serializable {

	private static final long serialVersionUID = 1L;

}
